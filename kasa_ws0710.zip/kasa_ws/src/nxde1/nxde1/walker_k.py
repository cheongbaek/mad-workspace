# walker_k : /in 구독 -> 아두이노 시리얼 입력 / 아두이노 시리얼 출력 -> /out 발행
#
# - /in (std_msgs/String) 메시지가 들어오는 대로 한 줄(개행 추가)로 아두이노에 즉시 전송
# - /in이 1초 이상 끊기면 마지막 값을 1초 주기로 재전송
#   (아두이노 5초 무입력 e-stop 방지 이중 안전장치)
# - 아두이노 시리얼 출력("<20번펄스> <21번펄스> <조향각도>")은 0.1초 주기로 읽어서
#   그 사이에 도착한 줄 중 가장 최신 완성 줄 하나만 /out (std_msgs/String) 으로 발행
#   (모든 줄을 전부 발행하지 않음)
# - 포트/보레이트 기본값은 아래 상수에서 결정 (플랫폼별 기본 포트),
#   실행 시 ROS 파라미터로 변경 가능:
#     ros2 run nxde1 walker_k --ros-args -p port:=/dev/ttyACM0 -p baud:=115200
# - 정상 동작 중에는 로그 출력 없이 조용히 중계만 함 (오류만 로그)

import sys
import time

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

import serial

# ===== 아두이노 시리얼 기본 설정 (파라미터 미지정 시 사용) =====
SERIAL_PORT = 'COM19' if sys.platform == 'win32' else '/dev/ttyUSB0'
BAUD_RATE   = 115200

SERIAL_POLL_S = 0.1   # 시리얼 수신 폴링(= /out 발행) 주기
RESEND_S      = 1.0   # /in 미수신 시 마지막 값 재전송 주기


class WalkerK(Node):
    def __init__(self):
        super().__init__('walker_k')

        port = self.declare_parameter('port', SERIAL_PORT).value
        baud = int(self.declare_parameter('baud', BAUD_RATE).value)
        try:
            self.ser = serial.Serial(port, baud, timeout=0)
        except serial.SerialException as e:
            self.get_logger().error(f"[아두이노 연결 실패] {port}: {e}")
            raise
        self.get_logger().info(f"[아두이노 연결 성공] {port} @ {baud}bps")

        self.sub = self.create_subscription(String, '/in', self.on_in, 10)
        self.pub = self.create_publisher(String, '/out', 10)

        self.rx_buf = b''
        self.last_line = None    # 마지막으로 전송한 /in 내용 (재전송용)
        self.last_sent = 0.0
        self.timer = self.create_timer(SERIAL_POLL_S, self.on_timer)

    def send_line(self, text):
        """한 줄(개행 추가)을 아두이노로 전송"""
        try:
            self.ser.write((text + '\n').encode('ascii'))
            self.last_sent = time.monotonic()
        except serial.SerialException as e:
            self.get_logger().error(f"시리얼 전송 실패: {e}")

    def on_in(self, msg):
        """/in 메시지가 들어오는 대로 즉시 전송"""
        self.last_line = msg.data.strip()
        self.send_line(self.last_line)

    def on_timer(self):
        self.poll_serial()
        # /in이 RESEND_S 이상 끊기면 마지막 값 재전송
        if self.last_line is not None and \
                time.monotonic() - self.last_sent >= RESEND_S:
            self.send_line(self.last_line)

    def poll_serial(self):
        """수신 버퍼를 비우고 가장 최신 완성 줄 하나만 /out 발행"""
        try:
            data = self.ser.read(4096)
        except serial.SerialException as e:
            self.get_logger().error(f"시리얼 수신 실패: {e}")
            return
        if data:
            self.rx_buf += data
        if b'\n' not in self.rx_buf:
            return

        lines = self.rx_buf.split(b'\n')
        self.rx_buf = lines[-1]             # 마지막 조각은 미완성 줄 -> 버퍼에 보존
        for line in reversed(lines[:-1]):   # 최신 완성 줄부터 검사
            text = line.decode('ascii', errors='ignore').strip()
            if text:
                msg = String()
                msg.data = text
                self.pub.publish(msg)
                break                       # 최신 한 줄만 발행

    def destroy_node(self):
        try:
            if self.ser.is_open:
                self.ser.close()
        except Exception:
            pass
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    try:
        node = WalkerK()
    except serial.SerialException:
        rclpy.shutdown()
        return
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
